const EventFunctions = {
    LoadCharacters: console.log
}