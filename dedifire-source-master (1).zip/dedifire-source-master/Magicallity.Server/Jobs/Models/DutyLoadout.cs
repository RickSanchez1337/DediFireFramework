﻿using System.Collections.Generic;

namespace Magicallity.Server.Jobs.Models
{
    public class DutyLoadout
    {
        public List<string> LoadoutWeapons = new List<string>();
    }
}
