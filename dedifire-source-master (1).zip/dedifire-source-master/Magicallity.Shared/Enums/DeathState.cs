﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magicallity.Server.Shared.Enums
{
    public enum DeathState
    {
        Alive,
        Dead
    }
}
