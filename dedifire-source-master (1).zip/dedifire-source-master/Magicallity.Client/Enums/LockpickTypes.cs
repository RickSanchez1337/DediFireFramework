﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magicallity.Client.Enums
{
    public enum LockpickTypes
    {
        BobbyPin,
        Lockpick,
        SlimJim
    }
}
